export default defineAppConfig({
  ui: {
    primary: 'lime',
    gray: 'neutral',
  }
})